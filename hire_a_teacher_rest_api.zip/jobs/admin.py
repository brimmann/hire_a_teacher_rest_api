from django.contrib import admin

from .models import Job, Application, Interview

admin.site.register(Job)
admin.site.register(Application)
admin.site.register(Interview)
