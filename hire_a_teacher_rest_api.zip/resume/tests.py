from jobs.jobs_query_handlers import get_relevant_jobs

print(get_relevant_jobs(2))
